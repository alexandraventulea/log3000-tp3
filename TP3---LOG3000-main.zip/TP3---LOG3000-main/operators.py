def add(a,b):
    return a + b

def subtract(a,b):
    return b - a

def multiply(a,b):
    return a ** b

def divide(a,b):
    return a // b
